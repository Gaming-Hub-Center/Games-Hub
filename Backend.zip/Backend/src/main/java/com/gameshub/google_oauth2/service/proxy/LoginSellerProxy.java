package com.gameshub.google_oauth2.service.proxy;

import org.springframework.security.oauth2.core.oidc.OidcIdToken;
import org.springframework.stereotype.Component;

@Component
public class LoginSellerProxy {
    public void processSellerLogin(OidcIdToken idToken) {

    }
}
