package com.gameshub.google_oauth2.service;

import com.gameshub.Model.Users.BuyerDAO;
import com.gameshub.Model.Users.SellerDAO;
import com.gameshub.Repository.SellerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.core.oidc.OidcIdToken;
import org.springframework.stereotype.Service;

@Service
public class SellerServiceOAuth2 { // TODO complete it

    @Autowired
    private SellerRepository sellerRepository;

    public void createUser(SellerDAO buyer) {
        sellerRepository.save(buyer);
    }

    public void createUser(OidcIdToken idToken) {
        System.out.println(idToken.getClaim("sub").toString());
        int userId = idToken.getClaim("sub").toString().hashCode();
        System.out.println(userId);
        //int userId =  Integer.parseInt(idToken.getClaim("sub").toString());
        String name = idToken.getClaim("name").toString();
        String email = idToken.getClaim("email").toString();

        SellerDAO seller = new SellerDAO(userId, name, email, null, null, null, 0, null, null, null, null);
        sellerRepository.save(seller);
    }

    public boolean emailAlreadyExist(OidcIdToken idToken) {
        String email = idToken.getClaim("email").toString();
        System.out.println(email);
        SellerDAO seller = sellerRepository.findByEmail(email).orElse(null);
        if(seller != null) {
            return true;
        }
        return false;
    }
}
