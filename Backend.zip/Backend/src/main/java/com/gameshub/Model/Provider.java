package com.gameshub.Model;

public enum Provider {
    LOCAL,
    GOOGLE
}
