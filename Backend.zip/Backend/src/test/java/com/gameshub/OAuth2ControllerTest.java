package com.gameshub;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.gameshub.Controller.OAuth2Controller;
import com.gameshub.google_oauth2.service.BuyerServiceOAuth2;
import com.gameshub.google_oauth2.service.SellerServiceOAuth2;
import com.gameshub.google_oauth2.service.proxy.CreateBuyerProxy;
import com.gameshub.google_oauth2.service.proxy.CreateSellerProxy;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.core.oidc.OidcIdToken;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@WebMvcTest(OAuth2Controller.class)
class OAuth2ControllerTest {

    @Autowired
    private OAuth2Controller oAuth2Controller;

    @MockBean
    private CreateBuyerProxy createBuyerProxy;
    @MockBean
    private CreateSellerProxy createSellerProxy;

    @MockBean
    private BuyerServiceOAuth2 buyerService;

    @MockBean
    private SellerServiceOAuth2 sellerService;

    @Test
    void testSignupPageBuyer_SuccessfulSignup() {
        OidcIdToken idToken = mock(OidcIdToken.class);
        DefaultOidcUser defaultOidcUser = mock(DefaultOidcUser.class);
        when(defaultOidcUser.getIdToken()).thenReturn(idToken);
        when(buyerService.emailAlreadyExist(idToken)).thenReturn(false);

        ResponseEntity<?> response = oAuth2Controller.signupPageBuyer(defaultOidcUser);

        assertEquals("Signed up successfully", response.getBody());
        assertEquals(200, response.getStatusCodeValue());
    }


}